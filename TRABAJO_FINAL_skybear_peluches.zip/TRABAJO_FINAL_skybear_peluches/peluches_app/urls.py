from django.urls import path
from peluches_app import views

urlpatterns = [
    path('',views.inicio_vista,name='inicio_vista'),
    path('registrarPeluche/',views.registrarPeluche,name="registrarPeluche"),
    path('seleccionarPeluche/<idpeluche>',views.seleccionarPeluche,name='seleccionarPeluche'),
    path('editarPeluche/',views.editarPeluche,name='editarPeluche'),
    path('borrarPeluche/<idpeluche>',views.borrarPeluche,name='borrarPeluche'),
]
