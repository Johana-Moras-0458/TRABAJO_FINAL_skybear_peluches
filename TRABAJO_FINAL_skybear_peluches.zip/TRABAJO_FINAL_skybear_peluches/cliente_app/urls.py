from django.urls import path
from cliente_app import views

urlpatterns = [
    path('',views.inicio_vista,name='inicio_vista'),
    path('registrarCliente/',views.registrarCliente,name="registrarCliente"),
    path('seleccionarCliente/<idcliente>',views.seleccionarCliente,name='seleccionarCliente'),
    path('editarCliente/',views.editarCliente,name='editarCliente'),
    path('borrarCliente/<idcliente>',views.borrarCliente,name='borrarCliente'),
]
